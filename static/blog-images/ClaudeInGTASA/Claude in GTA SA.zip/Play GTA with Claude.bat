@echo off
rem Starts the Claude Chat bridge in its own minimized window, then the game.
start "Claude Chat bridge" /min /D "%~dp0claude_chat" python -I bridge.py
start "" /D "%~dp0" "%~dp0gta_sa.exe"
