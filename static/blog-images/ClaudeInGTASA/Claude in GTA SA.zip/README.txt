Claude Chat for GTA San Andreas (PC, v1.0 US)
==============================================

Talk to Claude inside GTA San Andreas: a chat box, a companion who follows you,
reactions to what happens in game, mission help, cheats on request, and crowds
that follow (and worship) you.

NEEDS (install these first):
  1. GTA San Andreas v1.0 US (HOODLUM / "compact" exe). Steam/Rockstar versions must be downgraded.
  2. Ultimate ASI Loader (32-bit): put dinput8.dll next to gta_sa.exe
       https://github.com/ThirteenAG/Ultimate-ASI-Loader/releases
  3. CLEO 4.4: copy CLEO.asi, bass.dll and the cleo folder into the game folder
     (do NOT copy its vorbisFile.dll / vorbisHooked.dll when you already use dinput8.dll)
       https://github.com/cleolibrary/CLEO4/releases
  4. Python 3 (tick "Add python.exe to PATH" while installing)   https://www.python.org/downloads/
  5. Claude Code, logged in with your Claude account (run "claude" once in a terminal to log in)
       https://claude.com/claude-code
  Recommended: SilentPatch   https://github.com/CookiePLMonster/SilentPatch/releases
     (two monitors and the game closes right after "Device Selection"? set UseDesktopRefreshRate=0 in SilentPatchSA.ini)

INSTALL:
  Copy everything in this zip into your GTA San Andreas folder (next to gta_sa.exe).

PLAY:
  1. Double-click "Play GTA with Claude.bat" (starts the Claude bridge + the game).
  2. Load a save, then type  claude  on your keyboard (like a cheat code).
  3. Type your message, ENTER to send. BACKSPACE on an empty line closes the box.

TRY:  where am I? / follow me / be a nurse / give her an AK / make everyone follow me /
      worship me / let them go / give me a jetpack / how do I do this mission? / stop commenting

SETTINGS:  claude_chat\settings.json  (model: "sonnet" or "haiku", events: true/false, companion_skin)
LOG:       claude_chat\chat_log.txt
