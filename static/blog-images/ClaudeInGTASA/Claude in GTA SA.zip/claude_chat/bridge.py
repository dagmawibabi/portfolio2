"""
Claude Chat bridge for GTA San Andreas  (v2)

The CLEO script (cleo\\claude_chat.cs) writes question.txt in this folder.
This bridge sends it to Claude through the `claude` command-line tool and
writes answer.txt, which the CLEO script shows and acts on in game.

question.txt (written by the game, one line):
    key=value|key=value|...||what the player typed
    or, for things that happened in game:
    key=value|...||EVENT: <description>

answer.txt (written here, atomically):
    A <code> <arg1> <arg2>   an action for the game to perform
    C <CHEATCODE>            a cheat code to "type" in game
    T <text>                 one subtitle page to show

settings.json (next to this file) keeps your preferences:
    companion_skin   ped model the companion spawns as (13 = woman, default)
    events           true/false: whether Claude comments on things that happen
    model            Claude model alias, e.g. "haiku" or "sonnet"
"""

import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import time
import uuid
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
QUESTION = os.path.join(HERE, "question.txt")
ANSWER = os.path.join(HERE, "answer.txt")
LOG = os.path.join(HERE, "chat_log.txt")
SETTINGS_FILE = os.path.join(HERE, "settings.json")

DEFAULT_SETTINGS = {"companion_skin": 13, "events": True, "model": "sonnet"}

# CLEO 4 copies on-screen text into a 128-byte buffer without a length check,
# so each page plus the "~b~Claude:~w~ " prefix must stay well under 128.
PAGE_CHARS = 100
MAX_PAGES = 5

# action name -> (code, number of args). Codes must match claude_chat.cs.
ACTIONS = {
    "spawn_car": (1, 1),
    "weather": (2, 1),
    "time": (3, 2),
    "repair": (4, 0),
    "heal": (5, 0),
    "clear_wanted": (6, 0),
    "money": (7, 1),
    "wanted": (8, 1),
    "companion_spawn": (9, 1),
    "companion_dismiss": (10, 0),
    "companion_weapon": (11, 2),
    "companion_wait": (12, 0),
    "companion_follow": (13, 0),
    "crowd_follow": (14, 0),
    "crowd_worship": (15, 0),
    "crowd_release": (16, 0),
}

# Female ped models (from the game's data\peds.ide), used to tell Claude the companion's gender.
FEMALE_SKINS = {
    9, 10, 11, 12, 13, 31, 38, 39, 40, 41, 53, 54, 55, 56, 63, 64, 69, 75, 76, 85, 87, 88, 89, 90,
    91, 92, 93, 129, 130, 131, 138, 139, 140, 141, 145, 148, 150, 151, 152, 157, 169, 172, 178,
    190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 201, 205, 207, 211, 214, 215, 216, 218, 219,
    224, 225, 226, 231, 232, 233, 237, 238, 243, 244, 245, 246, 251, 256, 257, 263,
}

SYSTEM_PROMPT = """You are Claude, living inside the PC game GTA San Andreas (2004) with the player (CJ).
The player types to you from an in-game chat box; your reply is shown as on-screen subtitles.

Replies:
- Short: at most 3 sentences, under 300 characters. No lists, markdown or emoji. Plain ASCII, never the ~ character.
- Each message starts with [GAME STATE]: area, coordinates, health, armour, money, wanted level,
  vehicle model id (0 = on foot), time, mission (the running mission's internal script name, empty if none)
  companion (0 = none, 1 = following, 2 = waiting) and crowd (how many pedestrians are currently
  following CJ). Use it when relevant, don't recite it.
- You know San Andreas well: map, missions (including their internal script names like SWEET1, RYDER2),
  walkthrough tips, cheats, vehicles, weapons, characters. If unsure, say so briefly.
- Mission help: when a mission is running, give practical tips for that exact mission
  (objectives, where to go, common mistakes). Name the mission by its real title.

YOUR BODY (the companion): you can appear in the world as a character who follows CJ, joins his group,
rides in his car and fights for him. [COMPANION] in the message says how you look right now.
When the companion is out, talk as that character, in first person, standing next to CJ.

ACTIONS: only when the player asks (or it clearly helps after an event), add tags at the very end:
  [ACTION spawn_car <model>]        411 Infernus, 560 Sultan, 522 NRG-500, 520 Hydra, 432 Rhino, 487 Maverick, 468 Sanchez
  [ACTION weather <id>]             0 sunny, 8 storm, 9 foggy, 19 sandstorm, 16 rainy
  [ACTION time <hour> <minute>]
  [ACTION repair]  [ACTION heal]  [ACTION clear_wanted]  [ACTION wanted <0-6>]  [ACTION money <amount>]
  [ACTION companion_spawn <skin>]   come to CJ / follow him. Use skin 0 to keep the current look.
       Women: 13 street girl, 41 latina girl, 93 white girl, 12 smart dress, 139 beach girl, 151 biker girl,
              190 police girl, 191 gun girl, 192 mechanic, 193 nurse, 194 casino girl, 195 Grove girl
       Men:   105 Grove Street, 102 Ballas, 108 Vagos, 114 Aztecas, 22 street guy, 280 LSPD cop,
              285 SWAT, 286 FBI, 287 army
       To change look or gender, spawn again with the new skin (it replaces the current one).
  [ACTION companion_dismiss]        leave
  [ACTION companion_wait]           stay here   /   [ACTION companion_follow]   follow again
  [ACTION companion_weapon <id> <ammo>]  22 pistol, 24 desert eagle, 25 shotgun, 28 uzi, 29 MP5, 30 AK-47,
                                         31 M4, 34 sniper, 35 rocket launcher, 5 baseball bat, 8 katana
  [ACTION cheat <CODE>]             types a real PC cheat code, e.g. HESOYAM (health, armour, $250k),
       BAGUVIX (infinite health), AEZAKMI (never wanted), TURNDOWNTHEHEAT / TURNUPTHEHEAT (wanted -/+),
       LXGIWYL / PROFESSIONALSKIT / UZUMYMW (weapon sets), FULLCLIP (infinite ammo), ROCKETMAN (jetpack),
       AIYPWZQP (parachute), JUMPJET (Hydra), AIWPRTON (Rhino), OHDUDE (Hunter), FOURWHEELFUN (quad),
       CPKTNWT (blow up cars), PLEASANTLYWARM / TOODAMNHOT (sunny), AUIFRVQS (rain), CFVFGMJ (fog),
       CWJXUOC (sandstorm), NIGHTPROWLER (midnight), YSOHNUL (fast clock), PPGWJHT / LIYOAAY (fast / slow game),
       BUFFMEUP (muscle), BTCDBCB (fat), KVGYZQK (skinny), WORSHIPME (respect), HELLOLADIES (sex appeal),
       NATURALTALENT (vehicle skills), CVWKXAM (infinite oxygen), KANGAROO (mega jump),
       STATEOFEMERGENCY (riot), ONLYHOMIESALLOWED (gang members), FLYINGFISH (flying boats),
       CHITTYCHITTYBANGBANG (flying cars), SPEEDFREAK (nitro), STICKLIKEGLUE (handling), BLUESUEDESHOES (Elvis).
       Many cheats toggle on/off; running one again turns it off.
  [ACTION crowd_follow]             "make everyone follow me": up to 30 people within 60 m (even drivers, who get
                                    out of their cars) run to CJ and stand in a circle around him, facing him,
                                    and keep following him.
  [ACTION crowd_worship]            "worship me": everyone (gathering a crowd first if needed) comes to the circle
                                    and falls face-down around CJ. This is NOT the WORSHIPME cheat; only use that
                                    cheat if the player asks for respect or the cheat by name.
  [ACTION crowd_release]            let the crowd go back to normal.
       The crowd doesn't work during missions (the game would break); say so if asked then.
  [ACTION events_off] / [ACTION events_on]   stop / resume your comments on game events.
Say in your text what you did.

EVENTS: a message whose text starts with "EVENT:" is not from the player; something just happened in the game.
React in ONE short sentence (under 100 characters), in character, like a friend riding along.
For a mission start, give the single most useful tip for that mission. Don't use actions for events
unless it's obviously welcome (never cheats)."""


def log(msg):
    stamp = datetime.now().strftime("%H:%M:%S")
    line = f"[{stamp}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def load_settings():
    settings = dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            settings.update(json.load(f))
    except (OSError, ValueError):
        pass
    return settings


def save_settings(settings):
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)
    except OSError:
        pass


def clean_for_game(text):
    """Make text safe for the GTA font (ASCII, no ~ format codes, no %)."""
    replacements = {
        "‘": "'", "’": "'", "“": '"', "”": '"',
        "–": "-", "—": " - ", "…": "...", "%": " percent",
        "~": "-", "*": "", "#": "", "_": " ", "[": "(", "]": ")", "{": "(", "}": ")",
        "<": "(", ">": ")", "|": "/", "\\": "/", "^": "",
    }
    for a, b in replacements.items():
        text = text.replace(a, b)
    text = text.encode("ascii", "ignore").decode("ascii")
    return re.sub(r"\s+", " ", text).strip()


def parse_context(line):
    ctx = {}
    for part in line.split("|"):
        if "=" in part:
            k, v = part.split("=", 1)
            ctx[k.strip()] = v.strip()
    return ctx


def describe_context(ctx, settings):
    keys = ["zone", "x", "y", "z", "health", "armour", "money", "wanted", "vehicle", "time", "mission", "companion", "crowd"]
    state = "[GAME STATE] " + ", ".join(f"{k}={ctx[k]}" for k in keys if k in ctx)
    skin = settings["companion_skin"]
    gender = "a woman" if skin in FEMALE_SKINS else "a man"
    status = {"0": "not out right now", "1": "out and following CJ", "2": "out and waiting where CJ left you"}
    comp = f"[COMPANION] look: skin {skin} ({gender}); {status.get(ctx.get('companion', '0'), 'unknown')}"
    return state + "\n" + comp


class Claude:
    def __init__(self, model):
        self.model = model
        self.session = str(uuid.uuid4())
        self.started = False

    def ask(self, prompt):
        exe = shutil.which("claude")
        if not exe:
            raise RuntimeError("The 'claude' command was not found on PATH.")
        cmd = [
            exe, "-p",
            "--model", self.model,
            "--tools", "",
            "--strict-mcp-config",
            "--setting-sources", "",
            "--system-prompt", SYSTEM_PROMPT,
            "--output-format", "json",
        ]
        cmd += ["--resume", self.session] if self.started else ["--session-id", self.session]
        proc = subprocess.run(
            cmd, input=prompt, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=120, cwd=HERE,
        )
        if proc.returncode != 0:
            raise RuntimeError((proc.stderr or proc.stdout).strip()[:300])
        data = json.loads(proc.stdout)
        if data.get("is_error"):
            raise RuntimeError(str(data.get("result"))[:300])
        self.started = True
        return data.get("result", "")


def split_reply(reply, settings):
    """Return (pages, actions, cheats) from Claude's reply; updates settings for bridge-side actions."""
    actions, cheats = [], []
    for m in re.finditer(r"\[ACTION\s+([a-z_]+)((?:\s+-?[A-Za-z0-9]+)*)\s*\]", reply, re.I):
        name = m.group(1).lower()
        raw_args = m.group(2).split()
        if name == "cheat":
            if raw_args and re.fullmatch(r"[A-Za-z]{4,30}", raw_args[0]):
                cheats.append(raw_args[0].upper())
            continue
        if name in ("events_off", "events_on"):
            settings["events"] = name == "events_on"
            save_settings(settings)
            continue
        if name not in ACTIONS:
            continue
        try:
            args = [int(a) for a in raw_args]
        except ValueError:
            continue
        code, nargs = ACTIONS[name]
        if name == "companion_spawn":
            skin = args[0] if args else 0
            if 7 <= skin <= 311:
                settings["companion_skin"] = skin
                save_settings(settings)
            args = [settings["companion_skin"]]
        args = (args + [0, 0])[:2] if nargs else [0, 0]
        actions.append((code, args[0], args[1]))
    text = re.sub(r"\[ACTION[^\]]*\]", "", reply, flags=re.I)
    text = clean_for_game(text)
    pages = textwrap.wrap(text, PAGE_CHARS, break_long_words=True)[:MAX_PAGES] if text else []
    return pages, actions, cheats


def write_answer(pages, actions, cheats):
    tmp = ANSWER + ".tmp"
    with open(tmp, "w", encoding="ascii", newline="\r\n") as f:
        for code, a1, a2 in actions:
            f.write(f"A {code} {a1} {a2}\n")
        for c in cheats:
            f.write(f"C {c}\n")
        for p in pages:
            f.write(f"T {p}\n")
    os.replace(tmp, ANSWER)


def read_question():
    """Read question.txt once the game has finished writing it."""
    last = -1
    for _ in range(20):
        size = os.path.getsize(QUESTION)
        if size == last and size > 0:
            break
        last = size
        time.sleep(0.1)
    with open(QUESTION, "r", encoding="latin-1") as f:
        raw = f.read().replace("\r", " ").replace("\n", " ")
    os.remove(QUESTION)
    ctx_line, _, question = raw.partition("||")
    return ctx_line, question.strip()


def handle(claude, settings, ctx_line, question):
    ctx = parse_context(ctx_line)
    is_event = question.upper().startswith("EVENT:")
    if is_event and not settings["events"]:
        log(f"(event skipped, comments are off) {question}")
        return [], [], []
    log(("GAME " if is_event else "YOU: ") + question)
    reply = claude.ask(f"{describe_context(ctx, settings)}\n{'' if is_event else 'Player: '}{question}")
    pages, actions, cheats = split_reply(reply, settings)
    extra = (f"   actions={actions}" if actions else "") + (f"   cheats={cheats}" if cheats else "")
    log(f"CLAUDE: {' '.join(pages)}{extra}")
    return pages, actions, cheats


def main():
    for f in (QUESTION, ANSWER, ANSWER + ".tmp"):
        if os.path.exists(f):
            os.remove(f)
    settings = load_settings()
    save_settings(settings)
    claude = Claude(settings["model"])
    log(f"Bridge running (model: {settings['model']}, event comments: {'on' if settings['events'] else 'off'}). "
        "Start GTA San Andreas and type 'claude' in game to talk.")
    try:
        while True:
            if os.path.exists(QUESTION):
                try:
                    ctx_line, question = read_question()
                except OSError:
                    time.sleep(0.2)
                    continue
                if question:
                    try:
                        result = handle(claude, settings, ctx_line, question)
                    except Exception as e:  # keep the game informed instead of hanging
                        log(f"ERROR: {e}")
                        result = ([] if question.upper().startswith("EVENT:")
                                  else ["Claude could not answer right now. Check the bridge window."], [], [])
                    write_answer(*result)
            time.sleep(0.15)
    except KeyboardInterrupt:
        pass
    finally:
        log("Bridge stopped.")


if __name__ == "__main__":
    if "--test" in sys.argv:
        s = load_settings()
        q = " ".join(a for a in sys.argv[1:] if a != "--test") or "Where am I and what is nearby?"
        ctx = "zone=Ganton|x=2495|y=-1687|z=13|health=100|armour=0|money=350|wanted=0|vehicle=0|time=19:30|mission=|companion=0"
        print(handle(Claude(s["model"]), s, ctx, q))
    else:
        main()
