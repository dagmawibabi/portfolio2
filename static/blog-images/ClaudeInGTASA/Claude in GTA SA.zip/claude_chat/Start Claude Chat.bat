@echo off
title Claude Chat bridge - keep this open while playing
cd /d "%~dp0"
python -I bridge.py
pause
